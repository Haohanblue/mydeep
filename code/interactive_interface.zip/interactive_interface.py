from flask import Flask, render_template_string, request, redirect, session
import torch
import torch.nn as nn
import os
import zipfile
import glob
import pandas as pd
import numpy as np
from collections import defaultdict

# ----------------------------
# 路径配置
# ----------------------------
BASE_DIR = "/root/ly_env"
DATA_ZIP = f"{BASE_DIR}/data_300W_user_30000.zip"
DATA_DIR = f"{BASE_DIR}/data_300W_user_30000"


# ----------------------------
# LightGCN模型
# ----------------------------
class LightGCN(nn.Module):
    def __init__(self, n_users, n_items, emb_dim=128, n_layers=4, device='cpu'):
        super().__init__()
        self.n_users = n_users
        self.n_items = n_items
        self.emb_dim = emb_dim
        self.n_layers = n_layers
        self.device = device

        self.user_emb = nn.Embedding(n_users, emb_dim)
        self.item_emb = nn.Embedding(n_items, emb_dim)
        nn.init.normal_(self.user_emb.weight, std=0.01)
        nn.init.normal_(self.item_emb.weight, std=0.01)

        self.adj = None

    def build_adj_matrix(self, interactions):
        n_nodes = self.n_users + self.n_items
        edges = []
        for u, i in interactions:
            edges.append((u, self.n_users + i))
            edges.append((self.n_users + i, u))

        edges = np.array(edges).T
        values = torch.ones(edges.shape[1], dtype=torch.float32)
        self.adj = torch.sparse_coo_tensor(
            indices=edges,
            values=values,
            size=(n_nodes, n_nodes),
            device=self.device
        )
        degrees = torch.sparse.sum(self.adj, dim=1).to_dense()
        degrees_inv_sqrt = torch.pow(degrees, -0.5)
        degrees_inv_sqrt[degrees_inv_sqrt == float('inf')] = 0
        diag = torch.sparse_coo_tensor(
            indices=torch.stack([torch.arange(n_nodes), torch.arange(n_nodes)]),
            values=degrees_inv_sqrt,
            size=(n_nodes, n_nodes),
            device=self.device
        )
        self.adj = diag @ self.adj @ diag

    def computer(self):
        all_emb = torch.cat([self.user_emb.weight, self.item_emb.weight], dim=0)
        embs = [all_emb]
        x = all_emb
        for _ in range(self.n_layers):
            x = torch.sparse.mm(self.adj, x)
            embs.append(x)
        out = torch.mean(torch.stack(embs, dim=0), dim=0)
        return out[:self.n_users, :], out[self.n_users:, :]

    def recommend(self, user_ids, topk=20):
        users_emb, items_emb = self.computer()
        user_emb = users_emb[user_ids]
        scores = torch.matmul(user_emb, items_emb.t())
        top_items = torch.topk(scores, k=topk, dim=1).indices
        return top_items.cpu().numpy()


# ----------------------------
# 推荐系统核心
# ----------------------------
class RecommendationSystem:
    def __init__(self):
        self.config = {"emb_dim": 128, "n_layers": 4, "topk": 20, "use_gpu": False}
        self.model = None
        self.user_id_map = {}
        self.item_id_map = {}
        self.all_raw_users = set()
        self.interactions = []
        self._load_all_data()

    def _unzip_data(self):
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR, exist_ok=True)
            print(f"正在解压数据集到 {DATA_DIR}...")
            with zipfile.ZipFile(DATA_ZIP, 'r') as zip_ref:
                zip_ref.extractall(DATA_DIR)
            print("数据集解压完成")

    def _load_interaction_data(self):
        self._unzip_data()
        data_files = glob.glob(os.path.join(DATA_DIR, "**/*.csv"), recursive=True)
        if not data_files:
            raise FileNotFoundError("未找到CSV格式的交互数据文件")
        
        df = pd.read_csv(data_files[0], header=None)
        if df.shape[1] < 2:
            raise ValueError("CSV文件至少需要包含用户ID和物品ID两列")
        
        interactions = []
        for _, row in df.iterrows():
            user_id = str(row[0]).strip()
            item_id = str(row[1]).strip()
            interactions.append((user_id, item_id))
            self.all_raw_users.add(user_id)
        print(f"已加载 {len(interactions)} 条用户-物品交互数据")
        return interactions

    def _load_mappings(self, interactions):
        raw_users = list({u for u, i in interactions})
        raw_items = list({i for u, i in interactions})
        
        self.user_id_map = {u: idx for idx, u in enumerate(raw_users)}
        raw_to_inner_item = {i: idx for idx, i in enumerate(raw_items)}
        self.item_id_map = {v: k for k, v in raw_to_inner_item.items()}
        
        return [(self.user_id_map[u], raw_to_inner_item[i]) for u, i in interactions]

    def _load_all_data(self):
        try:
            raw_interactions = self._load_interaction_data()
            self.interactions = self._load_mappings(raw_interactions)
            n_users = len(self.user_id_map)
            n_items = len(self.item_id_map)
            print(f"用户数: {n_users}, 物品数: {n_items}")
            
            device = torch.device("cuda" if self.config["use_gpu"] and torch.cuda.is_available() else "cpu")
            self.model = LightGCN(
                n_users=n_users,
                n_items=n_items,
                emb_dim=self.config["emb_dim"],
                n_layers=self.config["n_layers"],
                device=device
            )
            self.model.build_adj_matrix(self.interactions)
            self.model.eval()
            print(f"LightGCN模型初始化完成 | 设备: {device}")

        except Exception as e:
            print(f"初始化失败: {str(e)}")
            raise

    def get_recommendations(self, user_id):
        if not user_id:
            return None, "请输入用户ID！"
        if user_id not in self.all_raw_users:
            return None, "请输入正确的用户ID！"
        
        try:
            inner_user_id = self.user_id_map[user_id]
            with torch.no_grad():
                top_inner_items = self.model.recommend(
                    user_ids=torch.tensor([inner_user_id], device=self.model.device),
                    topk=self.config["topk"]
                )[0]
            recommendations = [self.item_id_map.get(inner_id, f"未知物品({inner_id})") 
                               for inner_id in top_inner_items]
            return recommendations, None
        except Exception as e:
            return None, f"推荐失败: {str(e)}"


# ----------------------------
# Flask Web应用（含登录功能）
# ----------------------------
app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # 用于session加密的密钥
rec_system = RecommendationSystem()

# 登录页面模板
LOGIN_TEMPLATE = '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>系统登录</title>
    <style>
        body { 
            font-family: "Microsoft YaHei", sans-serif; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
            background-color: #f0f0f0; 
        }
        .login-container { 
            background: white; 
            padding: 40px; 
            border-radius: 10px; 
            box-shadow: 0 0 15px rgba(0,0,0,0.2); 
            width: 350px; 
        }
        h1 { 
            color: #333; 
            text-align: center; 
            margin-bottom: 30px; 
        }
        .input-group { 
            margin-bottom: 20px; 
        }
        label { 
            display: block; 
            margin-bottom: 8px; 
            color: #555; 
        }
        input { 
            width: 100%; 
            padding: 10px; 
            border: 2px solid #ddd; 
            border-radius: 5px; 
            font-size: 16px; 
        }
        button { 
            width: 100%; 
            padding: 12px; 
            background: #4CAF50; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            font-size: 16px; 
            cursor: pointer; 
            margin-top: 10px; 
        }
        button:hover { 
            background: #45a049; 
        }
        .error { 
            color: #dc3545; 
            text-align: center; 
            margin-top: 15px; 
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>系统登录</h1>
        <form method="post">
            <div class="input-group">
                <label for="username">账户名</label>
                <input type="text" id="username" name="username" placeholder="请输入账户名" required>
            </div>
            <div class="input-group">
                <label for="password">密码</label>
                <input type="password" id="password" name="password" placeholder="请输入密码" required>
            </div>
            <button type="submit">登录</button>
            {% if error %}
                <div class="error">{{ error }}</div>
            {% endif %}
        </form>
    </div>
</body>
</html>
'''

# 查询页面模板（原推荐查询界面）
QUERY_TEMPLATE = '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>LightGCN推荐系统</title>
    <style>
        body { font-family: "Microsoft YaHei", sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; background: #f0f0f0; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .logout { text-align: right; margin-bottom: 20px; }
        .logout-btn { color: #dc3545; text-decoration: none; }
        .logout-btn:hover { text-decoration: underline; }
        h1 { color: #333; text-align: center; }
        .input-area { text-align: center; margin: 30px 0; }
        #user_id { padding: 10px; width: 300px; font-size: 16px; border: 2px solid #ddd; border-radius: 5px; }
        button { padding: 10px 20px; font-size: 16px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px; }
        button:hover { background: #45a049; }
        .result-area { margin: 20px 0; padding: 20px; border-radius: 5px; min-height: 300px; }
        .error { color: #dc3545; text-align: center; font-size: 18px; }
        .success { color: #28a745; }
        .item-list { list-style: none; padding: 0; }
        .item-list li { padding: 10px; margin: 5px 0; background: #f9f9f9; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logout">
            <a href="/logout" class="logout-btn">退出登录</a>
        </div>
        <h1>LightGCN商品推荐系统</h1>
        <div class="input-area">
            <form method="post">
                <input type="text" id="user_id" name="user_id" placeholder="请输入用户ID" value="{{ user_id if user_id else '' }}">
                <button type="submit">查询推荐</button>
            </form>
        </div>
        <div class="result-area">
            {% if error %}
                <div class="error">{{ error }}</div>
            {% elif recommendations %}
                <div class="success">
                    <h3>用户 {{ user_id }} 的Top20推荐商品ID：</h3>
                    <ul class="item-list">
                        {% for item in recommendations %}
                            <li>{{ loop.index }}. {{ item }}</li>
                        {% endfor %}
                    </ul>
                </div>
            {% else %}
                <div style="text-align: center; color: #666;">请输入用户ID并点击查询</div>
            {% endif %}
        </div>
    </div>
</body>
</html>
'''

# 登录路由
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # 获取表单提交的账户和密码
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        # 验证账户密码（固定为master/12345678）
        if username == 'master' and password == '12345678':
            # 登录成功，记录session
            session['logged_in'] = True
            return redirect('/query')  # 跳转到查询页面
        else:
            # 登录失败，显示错误信息
            return render_template_string(LOGIN_TEMPLATE, error="账户名或密码错误，请重新输入")
    
    # GET请求显示登录页面
    return render_template_string(LOGIN_TEMPLATE)

# 查询页面路由（需要登录才能访问）
@app.route('/query', methods=['GET', 'POST'])
def query():
    # 检查是否登录，未登录则跳回登录页
    if not session.get('logged_in'):
        return redirect('/')
    
    user_id = ''
    recommendations = None
    error = ''
    if request.method == 'POST':
        user_id = request.form.get('user_id', '').strip()
        recommendations, error = rec_system.get_recommendations(user_id)
    
    return render_template_string(QUERY_TEMPLATE, 
                                 user_id=user_id, 
                                 recommendations=recommendations, 
                                 error=error)

# 退出登录路由
@app.route('/logout')
def logout():
    # 清除session
    session.pop('logged_in', None)
    return redirect('/')  # 跳回登录页


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)