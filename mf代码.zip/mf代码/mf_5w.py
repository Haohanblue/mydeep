import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from collections import defaultdict
import math
import warnings
import json
import os
import random

warnings.filterwarnings('ignore')

# 设置随机种子
def set_seed(seed=42):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    random.seed(seed)

set_seed(42)

# 设备配置
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# ========== 1. 简单但有效的数据加载 ==========
class SimpleDataset:
    def __init__(self, train_path, valid_path, test_path):
        print("="*60)
        print("Loading 50K Dataset")
        print("="*60)
        
        # 加载数据
        self.train_df = self._load_csv(train_path, "train")
        self.valid_df = self._load_csv(valid_path, "valid")
        self.test_df = self._load_csv(test_path, "test")
        
        # 预处理
        self._preprocess()
        
        # 构建交互
        self.build_interactions()
        
        print(f"\nDataset Statistics:")
        print(f"  Users: {self.n_users:,}")
        print(f"  Items: {self.n_items:,}")
        print(f"  Train interactions: {len(self.train_df):,}")
        print(f"  Valid interactions: {len(self.valid_df):,}")
        print(f"  Test interactions: {len(self.test_df):,}")
    
    def _load_csv(self, path, name):
        """简单加载CSV文件"""
        try:
            if os.path.exists(path) and os.path.getsize(path) > 0:
                df = pd.read_csv(path)
                print(f"  Loaded {name}: {len(df):,} rows")
                return df
            else:
                print(f"  ⚠ {name} file not found or empty, creating sample data")
                return self._create_sample_data(name)
        except:
            print(f"  ⚠ Error loading {name}, creating sample data")
            return self._create_sample_data(name)
    
    def _create_sample_data(self, name):
        """创建高质量的5w示例数据"""
        # 创建更密集、更有结构的数据
        n_users = 1200
        n_items = 4000
        
        # 创建用户和物品的聚类
        user_clusters = np.random.randint(0, 10, n_users)
        item_clusters = np.random.randint(0, 10, n_items)
        
        data = []
        
        # 为每个用户生成交互
        for user_id in range(n_users):
            # 同簇物品有更高概率被交互
            same_cluster_items = np.where(item_clusters == user_clusters[user_id])[0]
            diff_cluster_items = np.where(item_clusters != user_clusters[user_id])[0]
            
            # 交互次数：25-40
            n_interactions = np.random.randint(25, 40)
            
            # 70%同簇物品，30%不同簇物品
            n_same = int(n_interactions * 0.7)
            n_diff = n_interactions - n_same
            
            # 同簇物品交互
            for _ in range(n_same):
                if len(same_cluster_items) > 0:
                    item_id = np.random.choice(same_cluster_items)
                    data.append([f'user_{user_id}', f'item_{item_id}', 'pv'])
            
            # 不同簇物品交互
            for _ in range(n_diff):
                if len(diff_cluster_items) > 0:
                    item_id = np.random.choice(diff_cluster_items)
                    data.append([f'user_{user_id}', f'item_{item_id}', 'pv'])
        
        df = pd.DataFrame(data, columns=['user_id', 'item_id', 'behavior_type'])
        
        # 分割数据
        df = df.sample(frac=1, random_state=42).reset_index(drop=True)
        
        # 根据名称返回不同大小的数据集
        if name == 'train':
            return df.iloc[:35000].copy()
        elif name == 'valid':
            return df.iloc[35000:42500].copy()
        else:
            return df.iloc[42500:].copy()
    
    def _preprocess(self):
        """预处理数据"""
        # 合并所有数据
        all_data = pd.concat([self.train_df, self.valid_df, self.test_df], ignore_index=True)
        
        # 提取用户和物品
        self.user_ids = sorted(all_data['user_id'].unique().tolist())
        self.item_ids = sorted(all_data['item_id'].unique().tolist())
        
        self.n_users = len(self.user_ids)
        self.n_items = len(self.item_ids)
        
        # 创建映射
        self.user2idx = {user: idx for idx, user in enumerate(self.user_ids)}
        self.item2idx = {item: idx for idx, item in enumerate(self.item_ids)}
        
        # 应用映射
        for df in [self.train_df, self.valid_df, self.test_df]:
            df['user_idx'] = df['user_id'].map(self.user2idx)
            df['item_idx'] = df['item_id'].map(self.item2idx)
            df = df.dropna(subset=['user_idx', 'item_idx'])
            df['user_idx'] = df['user_idx'].astype(int)
            df['item_idx'] = df['item_idx'].astype(int)
    
    def build_interactions(self):
        """构建交互集合"""
        print("\n" + "="*60)
        print("Building Interactions")
        print("="*60)
        
        self.train_interactions = defaultdict(set)
        self.valid_interactions = defaultdict(set)
        self.test_interactions = defaultdict(set)
        
        # 构建训练集交互
        for _, row in self.train_df.iterrows():
            self.train_interactions[row['user_idx']].add(row['item_idx'])
        
        # 构建验证集交互
        for _, row in self.valid_df.iterrows():
            self.valid_interactions[row['user_idx']].add(row['item_idx'])
        
        # 构建测试集交互
        for _, row in self.test_df.iterrows():
            self.test_interactions[row['user_idx']].add(row['item_idx'])
        
        print(f"  Train users: {len(self.train_interactions):,}")
        print(f"  Valid users: {len(self.valid_interactions):,}")
        print(f"  Test users: {len(self.test_interactions):,}")
        
        # 预计算负样本
        all_items = set(range(self.n_items))
        self.negative_candidates = {}
        
        for user_idx in self.train_interactions:
            self.negative_candidates[user_idx] = list(all_items - self.train_interactions[user_idx])
        
        print(f"  Negative candidates computed")

# ========== 2. 简单有效的MF-BPR模型 ==========
class SimpleMF_BPR(nn.Module):
    def __init__(self, n_users, n_items, embedding_dim=64):
        super(SimpleMF_BPR, self).__init__()
        
        # 简单的嵌入层
        self.user_emb = nn.Embedding(n_users, embedding_dim)
        self.item_emb = nn.Embedding(n_items, embedding_dim)
        
        # 简单的初始化
        nn.init.normal_(self.user_emb.weight, mean=0, std=0.01)
        nn.init.normal_(self.item_emb.weight, mean=0, std=0.01)
        
    def forward(self, user_indices, item_indices):
        user_vec = self.user_emb(user_indices)
        item_vec = self.item_emb(item_indices)
        return torch.sum(user_vec * item_vec, dim=1)
    
    def get_user_embedding(self, user_indices):
        return self.user_emb(user_indices)
    
    def get_item_embedding(self, item_indices):
        return self.item_emb(item_indices)

# ========== 3. 简单BPR损失 ==========
class SimpleBPRLoss(nn.Module):
    def __init__(self):
        super(SimpleBPRLoss, self).__init__()
    
    def forward(self, pos_scores, neg_scores):
        # 简单的BPR损失
        diff = pos_scores - neg_scores
        loss = -torch.mean(F.logsigmoid(diff))
        return loss

# ========== 4. 数据集加载器 ==========
class SimpleBPRDataset(Dataset):
    def __init__(self, user_interactions, negative_candidates):
        self.samples = []
        
        # 为每个用户的正样本生成负样本
        for user_idx, pos_items in user_interactions.items():
            if user_idx not in negative_candidates:
                continue
                
            neg_items = negative_candidates[user_idx]
            if len(neg_items) == 0:
                continue
            
            for pos_item in pos_items:
                # 为每个正样本选择1个负样本
                neg_item = np.random.choice(neg_items)
                self.samples.append((user_idx, pos_item, neg_item))
        
        print(f"  Created {len(self.samples):,} training samples")
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        user, pos_item, neg_item = self.samples[idx]
        return (
            torch.tensor(user, dtype=torch.long),
            torch.tensor(pos_item, dtype=torch.long),
            torch.tensor(neg_item, dtype=torch.long)
        )

# ========== 5. 简单评估器 ==========
class SimpleEvaluator:
    def __init__(self, train_interactions, test_interactions, n_items, k=20):
        self.train_interactions = train_interactions
        self.test_interactions = test_interactions
        self.n_items = n_items
        self.k = k
    
    def evaluate(self, model):
        model.eval()
        recall_list = []
        ndcg_list = []
        hit_list = []
        
        users_with_test = list(self.test_interactions.keys())
        print(f"\n  Evaluating {len(users_with_test):,} users")
        
        with torch.no_grad():
            for user_idx in users_with_test:
                test_pos = self.test_interactions[user_idx]
                if not test_pos:
                    continue
                
                # 获取训练集正样本
                train_pos = self.train_interactions.get(user_idx, set())
                
                # 负样本候选
                all_items = set(range(self.n_items))
                neg_candidates = list(all_items - train_pos - test_pos)
                
                # 如果负样本太少，跳过
                if len(neg_candidates) < 50:
                    continue
                
                # 采样99个负样本
                neg_samples = np.random.choice(neg_candidates, min(99, len(neg_candidates)), replace=False)
                eval_items = list(test_pos) + list(neg_samples)
                
                # 计算得分
                user_tensor = torch.tensor([user_idx], dtype=torch.long).to(device)
                items_tensor = torch.tensor(eval_items, dtype=torch.long).to(device)
                
                scores = model(user_tensor, items_tensor).cpu().numpy()
                
                # 排序
                top_indices = np.argsort(scores)[-self.k:][::-1]
                top_items = [eval_items[i] for i in top_indices]
                
                # 计算指标
                hit_items = set(top_items) & test_pos
                recall = len(hit_items) / len(test_pos)
                
                # NDCG
                dcg = 0.0
                for i, item in enumerate(top_items):
                    if item in test_pos:
                        dcg += 1 / math.log2(i + 2)
                
                idcg = 0.0
                for i in range(min(len(test_pos), self.k)):
                    idcg += 1 / math.log2(i + 2)
                
                ndcg = dcg / idcg if idcg > 0 else 0.0
                
                # Hit Rate
                hit = 1.0 if len(hit_items) > 0 else 0.0
                
                recall_list.append(recall)
                ndcg_list.append(ndcg)
                hit_list.append(hit)
        
        if recall_list:
            avg_recall = np.mean(recall_list)
            avg_ndcg = np.mean(ndcg_list)
            avg_hit = np.mean(hit_list)
            
            print(f"  Recall@{self.k}: {avg_recall:.4f}")
            print(f"  NDCG@{self.k}: {avg_ndcg:.4f}")
            print(f"  HitRate@{self.k}: {avg_hit:.4f}")
            
            return avg_recall, avg_ndcg, avg_hit
        else:
            print("  ⚠ No valid users for evaluation")
            return 0.0, 0.0, 0.0

# ========== 6. 简单训练函数 ==========
def simple_train(model, train_loader, val_evaluator, optimizer, criterion, epochs=20):
    best_recall = 0.0
    train_losses = []
    
    print(f"\nTraining for {epochs} epochs")
    print("-" * 50)
    
    for epoch in range(epochs):
        model.train()
        epoch_loss = 0.0
        batch_count = 0
        
        for batch_idx, (users, pos_items, neg_items) in enumerate(train_loader):
            users = users.to(device)
            pos_items = pos_items.to(device)
            neg_items = neg_items.to(device)
            
            # 前向传播
            pos_scores = model(users, pos_items)
            neg_scores = model(users, neg_items)
            loss = criterion(pos_scores, neg_scores)
            
            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss.item()
            batch_count += 1
            
            # 每100个batch打印一次
            if (batch_idx + 1) % 100 == 0:
                avg_loss = epoch_loss / batch_count
                print(f"  Epoch {epoch+1:02d} | Batch {batch_idx+1:04d} | Loss: {avg_loss:.4f}")
        
        # 计算平均损失
        avg_loss = epoch_loss / max(batch_count, 1)
        train_losses.append(avg_loss)
        
        # 验证
        model.eval()
        recall, ndcg, hit = val_evaluator.evaluate(model)
        
        print(f"\n  Epoch {epoch+1:02d}/{epochs:02d}")
        print(f"  Train Loss: {avg_loss:.4f}")
        print(f"  Val Recall@20: {recall:.4f}")
        
        # 保存最佳模型
        if recall > best_recall:
            best_recall = recall
            torch.save(model.state_dict(), 'simple_best_model.pth')
            print(f"  ✅ Saved best model (Recall: {recall:.4f})")
        
        # 如果损失已经很小，可以提前停止
        if avg_loss < 0.1 and epoch > 5:
            print(f"  Loss is small enough, stopping early")
            break
    
    print(f"\nBest validation Recall@20: {best_recall:.4f}")
    return train_losses, best_recall

# ========== 7. 主函数 ==========
def main():
    # 数据路径
    base_path = '/root/lcx'
    train_path = os.path.join(base_path, 'train.csv')
    valid_path = os.path.join(base_path, 'valid.csv')
    test_path = os.path.join(base_path, 'test.csv')
    
    print("\n" + "="*60)
    print("SIMPLE MF-BPR for 50K Dataset")
    print("="*60)
    
    # 1. 加载数据
    print("\n[1/4] Loading Data")
    print("-" * 40)
    
    dataset = SimpleDataset(train_path, valid_path, test_path)
    
    if len(dataset.train_interactions) == 0:
        print("⚠ No training data!")
        return
    
    # 2. 创建数据加载器
    print("\n[2/4] Creating Data Loader")
    print("-" * 40)
    
    train_dataset = SimpleBPRDataset(dataset.train_interactions, dataset.negative_candidates)
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=512,
        shuffle=True,
        num_workers=0  # 避免多线程问题
    )
    
    # 3. 创建模型
    print("\n[3/4] Creating Model")
    print("-" * 40)
    
    model = SimpleMF_BPR(
        n_users=dataset.n_users,
        n_items=dataset.n_items,
        embedding_dim=64
    ).to(device)
    
    # 优化器和损失函数
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = SimpleBPRLoss()
    
    # 评估器
    val_evaluator = SimpleEvaluator(
        dataset.train_interactions,
        dataset.valid_interactions,
        dataset.n_items,
        k=20
    )
    
    test_evaluator = SimpleEvaluator(
        dataset.train_interactions,
        dataset.test_interactions,
        dataset.n_items,
        k=20
    )
    
    # 4. 训练模型
    print("\n[4/4] Training Model")
    print("-" * 40)
    
    train_losses, best_recall = simple_train(
        model, train_loader, val_evaluator, optimizer, criterion, epochs=20
    )
    
    # 5. 测试最佳模型
    print("\n" + "="*60)
    print("Testing Best Model")
    print("="*60)
    
    # 加载最佳模型
    if os.path.exists('simple_best_model.pth'):
        model.load_state_dict(torch.load('simple_best_model.pth', map_location=device))
        print("  Loaded best model")
    
    # 测试集评估
    print("\nTest Set Evaluation:")
    test_recall, test_ndcg, test_hit = test_evaluator.evaluate(model)
    
    # 6. 保存结果
    results = {
        "data_statistics": {
            "n_users": dataset.n_users,
            "n_items": dataset.n_items,
            "train_interactions": len(dataset.train_df),
            "test_interactions": len(dataset.test_df)
        },
        "model_config": {
            "embedding_dim": 64,
            "batch_size": 512,
            "learning_rate": 0.001
        },
        "results": {
            "best_val_recall": best_recall,
            "test_recall": test_recall,
            "test_ndcg": test_ndcg,
            "test_hitrate": test_hit,
            "final_train_loss": train_losses[-1] if train_losses else 0
        }
    }
    
    with open('simple_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to simple_results.json")
    
    # 7. 打印总结
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print(f"Dataset: {dataset.n_users:,} users, {dataset.n_items:,} items")
    print(f"Train size: {len(dataset.train_df):,} interactions")
    print(f"Test size: {len(dataset.test_df):,} interactions")
    print(f"\nPerformance:")
    print(f"  Best Val Recall@20: {best_recall:.4f}")
    print(f"  Test Recall@20: {test_recall:.4f}")
    print(f"  Test NDCG@20: {test_ndcg:.4f}")
    print(f"  Test HitRate@20: {test_hit:.4f}")
    
    if test_recall > 0.15:
        print(f"\n✅ Good performance! Recall > 0.15")
    elif test_recall > 0.10:
        print(f"\n👍 Acceptable performance! Recall > 0.10")
    else:
        print(f"\n⚠ Needs improvement! Recall < 0.10")
    
    return results

# ========== 运行程序 ==========
if __name__ == "__main__":
    try:
        results = main()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()