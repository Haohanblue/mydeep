import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from collections import defaultdict, Counter
import math
import warnings
import json
import os
import random
import time

warnings.filterwarnings('ignore')

# 设置随机种子
def set_seed(seed=42):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    random.seed(seed)

set_seed(42)

# 设备配置
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# ========== 1. 数据加载和预处理（优化数据质量） ==========
class RecommendationDataset:
    def __init__(self, train_path, valid_path, test_path, min_interactions=3):
        """
        初始化数据集类
        """
        self.min_interactions = min_interactions
        print("="*60)
        print("Step 1: Load and Process Data")
        print("="*60)
        
        self.train_path = train_path
        self.valid_path = valid_path
        self.test_path = test_path
        
        # 读取或生成数据
        self._load_or_generate_data()
        
        # 预处理列名
        self._preprocess_columns()
        
        # 数据清洗
        self._clean_data()
        
        # 过滤低频用户/物品
        self._filter_low_frequency()
        
        # 最终预处理
        self._preprocess_data()
        
        # 构建交互
        self.build_interactions()
    
    def _load_or_generate_data(self):
        """读取或生成数据"""
        # 尝试读取真实文件
        if os.path.exists(self.train_path) and os.path.getsize(self.train_path) > 1000:
            try:
                self.train_df = pd.read_csv(self.train_path)
                self.valid_df = pd.read_csv(self.valid_path)
                self.test_df = pd.read_csv(self.test_path)
                print(f"  Read real data: train={len(self.train_df)}, valid={len(self.valid_df)}, test={len(self.test_df)}")
                return
            except:
                print("  Failed to read real data, generating simulation data...")
        
        # 生成模拟数据
        print("  Generating simulation data...")
        self._generate_simulation_data()
    
    def _generate_simulation_data(self):
        """生成模拟数据"""
        # 设置参数
        n_users = 500
        n_items = 2000
        n_interactions = 50000
        
        # 创建交互
        interactions = []
        
        # 为每个用户生成基础交互
        for user in range(n_users):
            min_interactions = np.random.randint(5, 20)
            for _ in range(min_interactions):
                item = np.random.randint(0, n_items)
                behavior = np.random.choice(['pv', 'pv', 'pv', 'collect', 'buy'], 
                                           p=[0.7, 0.15, 0.1, 0.03, 0.02])
                interactions.append({
                    'user_id': f'user_{user}',
                    'item_id': f'item_{item}',
                    'behavior_type': behavior
                })
        
        # 添加随机交互
        additional_interactions = n_interactions - len(interactions)
        for _ in range(additional_interactions):
            user = np.random.randint(0, n_users)
            item = np.random.randint(0, n_items)
            behavior = np.random.choice(['pv', 'pv', 'pv', 'collect', 'buy'], 
                                       p=[0.7, 0.15, 0.1, 0.03, 0.02])
            interactions.append({
                'user_id': f'user_{user}',
                'item_id': f'item_{item}',
                'behavior_type': behavior
            })
        
        # 转换为DataFrame并分割
        all_df = pd.DataFrame(interactions)
        
        # 随机分割：70%训练，15%验证，15%测试
        train_size = int(len(all_df) * 0.7)
        valid_size = int(len(all_df) * 0.15)
        
        self.train_df = all_df.iloc[:train_size].copy()
        self.valid_df = all_df.iloc[train_size:train_size + valid_size].copy()
        self.test_df = all_df.iloc[train_size + valid_size:].copy()
        
        print(f"  Generated: train={len(self.train_df)}, valid={len(self.valid_df)}, test={len(self.test_df)}")
    
    def _preprocess_columns(self):
        """统一列名"""
        for df, data_type in [(self.train_df, "train"), (self.valid_df, "valid"), (self.test_df, "test")]:
            if df.empty:
                continue
            
            # 标准化列名
            col_mapping = {}
            for col in df.columns:
                col_lower = str(col).lower()
                if 'user' in col_lower and ('id' in col_lower or col_lower == 'user'):
                    col_mapping[col] = 'user_id'
                elif 'item' in col_lower and ('id' in col_lower or col_lower == 'item'):
                    col_mapping[col] = 'item_id'
                elif 'behavior' in col_lower or 'type' in col_lower or 'action' in col_lower:
                    col_mapping[col] = 'behavior_type'
            
            if col_mapping:
                df.rename(columns=col_mapping, inplace=True)
            
            # 确保有必要的列
            if 'user_id' not in df.columns and len(df.columns) > 0:
                df.rename(columns={df.columns[0]: 'user_id'}, inplace=True)
            if 'item_id' not in df.columns and len(df.columns) > 1:
                df.rename(columns={df.columns[1]: 'item_id'}, inplace=True)
            if 'behavior_type' not in df.columns:
                df['behavior_type'] = 'pv'
    
    def _clean_data(self):
        """数据清洗"""
        for df, name in [(self.train_df, 'train'), (self.valid_df, 'valid'), (self.test_df, 'test')]:
            if df.empty:
                continue
            
            original_len = len(df)
            
            # 移除缺失值
            df.dropna(subset=['user_id', 'item_id'], inplace=True)
            
            # 转换为字符串
            df['user_id'] = df['user_id'].astype(str)
            df['item_id'] = df['item_id'].astype(str)
            
            # 移除重复
            df.drop_duplicates(subset=['user_id', 'item_id'], keep='first', inplace=True)
            
            cleaned = original_len - len(df)
            if cleaned > 0:
                print(f"  Cleaned {name}: removed {cleaned} invalid/duplicate rows")
    
    def _filter_low_frequency(self):
        """过滤低频用户和物品"""
        if self.train_df.empty:
            return
        
        # 合并所有数据
        all_data = pd.concat([self.train_df, self.valid_df, self.test_df], ignore_index=True)
        
        # 统计频率
        user_counts = all_data['user_id'].value_counts()
        item_counts = all_data['item_id'].value_counts()
        
        print(f"  Before filtering: {len(user_counts)} users, {len(item_counts)} items")
        
        # 过滤
        valid_users = user_counts[user_counts >= self.min_interactions].index
        valid_items = item_counts[item_counts >= 1].index
        
        print(f"  Valid users: {len(valid_users)} (>= {self.min_interactions} interactions)")
        print(f"  Valid items: {len(valid_items)} (>= 1 interaction)")
        
        # 应用过滤
        self.train_df = self.train_df[
            self.train_df['user_id'].isin(valid_users) & 
            self.train_df['item_id'].isin(valid_items)
        ]
        self.valid_df = self.valid_df[
            self.valid_df['user_id'].isin(valid_users) & 
            self.valid_df['item_id'].isin(valid_items)
        ]
        self.test_df = self.test_df[
            self.test_df['user_id'].isin(valid_users) & 
            self.test_df['item_id'].isin(valid_items)
        ]
    
    def _preprocess_data(self):
        """最终预处理"""
        # 合并数据
        all_data = pd.concat([self.train_df, self.valid_df, self.test_df], ignore_index=True)
        
        # 获取唯一的用户和物品ID
        self.user_ids = sorted(all_data['user_id'].unique().tolist())
        self.item_ids = sorted(all_data['item_id'].unique().tolist())
        
        self.n_users = len(self.user_ids)
        self.n_items = len(self.item_ids)
        
        # 创建映射字典
        self.user2idx = {user: idx for idx, user in enumerate(self.user_ids)}
        self.item2idx = {item: idx for idx, item in enumerate(self.item_ids)}
        
        # 应用映射
        for df, name in [(self.train_df, 'train'), (self.valid_df, 'valid'), (self.test_df, 'test')]:
            if not df.empty:
                df['user_idx'] = df['user_id'].map(self.user2idx)
                df['item_idx'] = df['item_id'].map(self.item2idx)
                df = df.dropna(subset=['user_idx', 'item_idx'])
                df['user_idx'] = df['user_idx'].astype(int)
                df['item_idx'] = df['item_idx'].astype(int)
        
        print(f"\n  Data Statistics:")
        print(f"    Unique users: {self.n_users}")
        print(f"    Unique items: {self.n_items}")
        print(f"    Train interactions: {len(self.train_df)}")
        print(f"    Valid interactions: {len(self.valid_df)}")
        print(f"    Test interactions: {len(self.test_df)}")
    
    def build_interactions(self):
        """构建用户-物品交互集合"""
        print("\n" + "="*60)
        print("Step 2: Build User-Item Interactions")
        print("="*60)
        
        self.train_interactions = defaultdict(set)
        self.valid_interactions = defaultdict(set)
        self.test_interactions = defaultdict(set)
        
        # 构建交互集合
        for _, row in self.train_df.iterrows():
            self.train_interactions[row['user_idx']].add(row['item_idx'])
        
        for _, row in self.valid_df.iterrows():
            self.valid_interactions[row['user_idx']].add(row['item_idx'])
        
        for _, row in self.test_df.iterrows():
            self.test_interactions[row['user_idx']].add(row['item_idx'])
        
        # 统计信息
        print(f"  Train: {len(self.train_interactions)} users with interactions")
        print(f"  Valid: {len(self.valid_interactions)} users with interactions")
        print(f"  Test: {len(self.test_interactions)} users with interactions")
        
        # 计算平均交互次数
        avg_train = np.mean([len(v) for v in self.train_interactions.values()])
        avg_valid = np.mean([len(v) for v in self.valid_interactions.values()])
        avg_test = np.mean([len(v) for v in self.test_interactions.values()])
        
        print(f"  Avg interactions per user:")
        print(f"    Train: {avg_train:.1f}")
        print(f"    Valid: {avg_valid:.1f}")
        print(f"    Test: {avg_test:.1f}")
        
        # 预计算负样本候选
        all_items = set(range(self.n_items))
        self.negative_candidates = {}
        
        for user_idx in self.train_interactions:
            neg_items = list(all_items - self.train_interactions[user_idx])
            if len(neg_items) > 0:
                self.negative_candidates[user_idx] = neg_items
        
        print(f"  Negative candidates computed for {len(self.negative_candidates)} users")

# ========== 2. MF-BPR模型 ==========
class MF_BPR(nn.Module):
    def __init__(self, n_users, n_items, embedding_dim=128):
        """
        矩阵分解BPR模型
        """
        super(MF_BPR, self).__init__()
        self.n_users = n_users
        self.n_items = n_items
        self.embedding_dim = embedding_dim
        
        # 用户和物品嵌入
        self.user_embeddings = nn.Embedding(n_users, embedding_dim)
        self.item_embeddings = nn.Embedding(n_items, embedding_dim)
        
        # 初始化
        nn.init.xavier_uniform_(self.user_embeddings.weight)
        nn.init.xavier_uniform_(self.item_embeddings.weight)
    
    def forward(self, user_indices, item_indices):
        """计算用户-物品得分"""
        user_emb = self.user_embeddings(user_indices)
        item_emb = self.item_embeddings(item_indices)
        scores = torch.sum(user_emb * item_emb, dim=1)
        return scores
    
    def get_user_embedding(self, user_indices):
        return self.user_embeddings(user_indices)
    
    def get_item_embedding(self, item_indices):
        return self.item_embeddings(item_indices)

# ========== 3. BPR损失函数 ==========
class BPRLoss(nn.Module):
    def __init__(self, lambda_reg=0.001):
        """
        BPR损失函数
        """
        super(BPRLoss, self).__init__()
        self.lambda_reg = lambda_reg
    
    def forward(self, pos_scores, neg_scores, user_emb=None, pos_item_emb=None, neg_item_emb=None):
        """计算BPR损失"""
        # BPR损失
        diff = pos_scores - neg_scores
        bpr_loss = -torch.mean(F.logsigmoid(diff))
        
        # L2正则化
        reg_loss = 0
        if user_emb is not None and self.lambda_reg > 0:
            reg_loss = self.lambda_reg * (
                torch.mean(torch.norm(user_emb, p=2, dim=1)) +
                torch.mean(torch.norm(pos_item_emb, p=2, dim=1)) +
                torch.mean(torch.norm(neg_item_emb, p=2, dim=1))
            )
        
        return bpr_loss + reg_loss

# ========== 4. 数据集加载器 ==========
class BPRDataset(Dataset):
    def __init__(self, user_interactions, negative_candidates, num_negatives=4):
        """
        BPR训练数据集
        """
        self.user_interactions = user_interactions
        self.negative_candidates = negative_candidates
        self.num_negatives = num_negatives
        
        # 生成训练样本
        self.samples = self._generate_samples()
        
        print(f"  Generated {len(self.samples)} training samples")
        print(f"  Positive:Negative ratio = 1:{num_negatives}")
    
    def _generate_samples(self):
        """生成训练样本"""
        samples = []
        
        for user_idx, pos_items in self.user_interactions.items():
            if user_idx not in self.negative_candidates:
                continue
            
            neg_candidates = self.negative_candidates[user_idx]
            if len(neg_candidates) < self.num_negatives:
                continue
            
            for pos_item in pos_items:
                # 采样负样本
                neg_items = np.random.choice(neg_candidates, self.num_negatives, replace=False)
                
                for neg_item in neg_items:
                    samples.append((user_idx, pos_item, neg_item))
        
        return samples
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        user, pos_item, neg_item = self.samples[idx]
        return (
            torch.tensor(user, dtype=torch.long),
            torch.tensor(pos_item, dtype=torch.long),
            torch.tensor(neg_item, dtype=torch.long)
        )

# ========== 5. 评估器（保持原有的评估指标） ==========
class Evaluator:
    def __init__(self, train_interactions, test_interactions, n_items, k=20, eval_neg_samples=100):
        """
        评估器 - 保持原有的评估指标
        """
        self.train_interactions = train_interactions
        self.test_interactions = test_interactions
        self.n_items = n_items
        self.k = k
        self.eval_neg_samples = eval_neg_samples
        
        # 预计算每个用户的负样本候选
        self.user_neg_candidates = {}
        all_items = set(range(n_items))
        
        for user_idx in test_interactions:
            test_pos = test_interactions[user_idx]
            train_pos = train_interactions.get(user_idx, set())
            
            # 负样本候选 = 所有物品 - 训练集正样本 - 测试集正样本
            neg_candidates = list(all_items - train_pos - test_pos)
            if len(neg_candidates) > 0:
                self.user_neg_candidates[user_idx] = neg_candidates
    
    def evaluate(self, model):
        """评估模型性能 - 保持原有的评估指标（Recall@20, NDCG@20, HitRate@20）"""
        model.eval()
        recall_list, ndcg_list, hit_rate_list = [], [], []
        
        users_with_test = list(self.test_interactions.keys())
        print(f"\n  Evaluating {len(users_with_test)} users")
        
        with torch.no_grad():
            for user_idx in users_with_test:
                test_pos = self.test_interactions[user_idx]
                
                if not test_pos or user_idx not in self.user_neg_candidates:
                    continue
                
                neg_candidates = self.user_neg_candidates[user_idx]
                
                # 构建评估列表
                if len(neg_candidates) >= self.eval_neg_samples:
                    neg_samples = np.random.choice(neg_candidates, self.eval_neg_samples, replace=False)
                else:
                    neg_samples = np.random.choice(neg_candidates, self.eval_neg_samples, replace=True)
                
                eval_items = list(test_pos) + list(neg_samples)
                
                # 计算得分
                user_tensor = torch.tensor([user_idx], dtype=torch.long).to(device)
                items_tensor = torch.tensor(eval_items, dtype=torch.long).to(device)
                
                user_emb = model.get_user_embedding(user_tensor)
                item_emb = model.get_item_embedding(items_tensor)
                scores = torch.matmul(user_emb, item_emb.T).squeeze(0).cpu().numpy()
                
                # 排序
                sorted_indices = np.argsort(scores)[::-1]
                top_k_items = [eval_items[i] for i in sorted_indices[:self.k]]
                
                # 计算指标（保持原有的指标）
                hit_pos = set(top_k_items) & test_pos
                
                # Recall@20
                recall = len(hit_pos) / len(test_pos)
                
                # NDCG@20
                dcg = 0.0
                for i, item in enumerate(top_k_items):
                    if item in test_pos:
                        dcg += 1 / math.log2(i + 2)
                
                idcg = 0.0
                for i in range(min(len(test_pos), self.k)):
                    idcg += 1 / math.log2(i + 2)
                
                ndcg = dcg / idcg if idcg > 0 else 0.0
                
                # HitRate@20（是否有测试集正样本出现在top-k中）
                hit_rate = 1.0 if len(hit_pos) > 0 else 0.0
                
                recall_list.append(recall)
                ndcg_list.append(ndcg)
                hit_rate_list.append(hit_rate)
        
        # 计算平均指标
        if recall_list:
            avg_recall = np.mean(recall_list)
            avg_ndcg = np.mean(ndcg_list)
            avg_hit_rate = np.mean(hit_rate_list)
            
            print(f"  Recall@{self.k}: {avg_recall:.4f}")
            print(f"  NDCG@{self.k}: {avg_ndcg:.4f}")
            print(f"  HitRate@{self.k}: {avg_hit_rate:.4f}")
            
            return avg_recall, avg_ndcg, avg_hit_rate
        else:
            print("  ⚠ No valid users for evaluation")
            return 0.0, 0.0, 0.0

# ========== 6. 训练函数 ==========
def train_model(model, train_loader, val_evaluator, optimizer, criterion, epochs=50):
    """
    训练模型
    """
    best_recall = 0.0
    best_epoch = 0
    train_losses = []
    
    print(f"\nTraining Model for {epochs} epochs")
    print("-" * 50)
    
    for epoch in range(epochs):
        model.train()
        epoch_loss = 0.0
        batch_count = 0
        
        for batch_idx, (users, pos_items, neg_items) in enumerate(train_loader):
            users = users.to(device)
            pos_items = pos_items.to(device)
            neg_items = neg_items.to(device)
            
            # 获取嵌入
            user_emb = model.get_user_embedding(users)
            pos_item_emb = model.get_item_embedding(pos_items)
            neg_item_emb = model.get_item_embedding(neg_items)
            
            # 计算得分和损失
            pos_scores = model(users, pos_items)
            neg_scores = model(users, neg_items)
            loss = criterion(pos_scores, neg_scores, user_emb, pos_item_emb, neg_item_emb)
            
            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss.item()
            batch_count += 1
            
            # 每50个batch打印一次
            if (batch_idx + 1) % 50 == 0:
                avg_loss = epoch_loss / batch_count
                print(f"  Epoch {epoch+1:02d} | Batch {batch_idx+1:04d} | Loss: {avg_loss:.4f}")
        
        # 计算平均损失
        avg_loss = epoch_loss / batch_count if batch_count > 0 else 0.0
        train_losses.append(avg_loss)
        
        # 验证
        model.eval()
        val_recall, val_ndcg, val_hit_rate = val_evaluator.evaluate(model)
        
        print(f"\n  Epoch {epoch+1:02d}/{epochs:02d}")
        print(f"  Train Loss: {avg_loss:.4f}")
        print(f"  Val Recall@{val_evaluator.k}: {val_recall:.4f}")
        print(f"  Val NDCG@{val_evaluator.k}: {val_ndcg:.4f}")
        
        # 保存最佳模型
        if val_recall > best_recall:
            best_recall = val_recall
            best_epoch = epoch + 1
            torch.save(model.state_dict(), 'best_mf_bpr_model.pth')
            print(f"  ✅ Saved best model (Recall: {best_recall:.4f})")
        
        # 早停检查
        if epoch - best_epoch >= 10:
            print(f"  Early stopping at epoch {epoch+1}")
            break
    
    print(f"\nBest model at epoch {best_epoch} with Recall@{val_evaluator.k}: {best_recall:.4f}")
    return train_losses, best_recall

# ========== 7. 主函数 ==========
def main():
    # 数据路径
    base_path = '/root/lcx'
    train_path = os.path.join(base_path, 'train.csv')
    valid_path = os.path.join(base_path, 'valid.csv')
    test_path = os.path.join(base_path, 'test.csv')
    
    print("\n" + "="*60)
    print("MF-BPR RECOMMENDATION SYSTEM")
    print("="*60)
    
    # 1. 加载和预处理数据
    print("\n[1/6] Loading and Preprocessing Data")
    print("-" * 40)
    
    dataset = RecommendationDataset(train_path, valid_path, test_path, min_interactions=3)
    
    if len(dataset.train_interactions) == 0:
        print("⚠ No training data available!")
        return
    
    # 2. 创建训练数据集
    print("\n[2/6] Creating Training Dataset")
    print("-" * 40)
    
    train_dataset = BPRDataset(
        user_interactions=dataset.train_interactions,
        negative_candidates=dataset.negative_candidates,
        num_negatives=4
    )
    
    if len(train_dataset) == 0:
        print("⚠ No training samples generated!")
        return
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=512,
        shuffle=True,
        num_workers=2 if torch.cuda.is_available() else 0,
        pin_memory=True if torch.cuda.is_available() else False
    )
    
    # 3. 创建模型
    print("\n[3/6] Creating MF-BPR Model")
    print("-" * 40)
    
    model = MF_BPR(
        n_users=dataset.n_users,
        n_items=dataset.n_items,
        embedding_dim=128
    ).to(device)
    
    # 计算参数数量
    total_params = sum(p.numel() for p in model.parameters())
    
    print(f"  Model Architecture:")
    print(f"    Users: {dataset.n_users:,}")
    print(f"    Items: {dataset.n_items:,}")
    print(f"    Embedding Dimension: 128")
    print(f"    Total Parameters: {total_params:,}")
    
    # 4. 创建损失函数和优化器
    criterion = BPRLoss(lambda_reg=0.001)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    # 5. 创建评估器
    val_evaluator = Evaluator(
        dataset.train_interactions,
        dataset.valid_interactions,
        dataset.n_items,
        k=20,
        eval_neg_samples=100
    )
    
    test_evaluator = Evaluator(
        dataset.train_interactions,
        dataset.test_interactions,
        dataset.n_items,
        k=20,
        eval_neg_samples=100
    )
    
    # 6. 训练模型
    print("\n[4/6] Training Model")
    print("-" * 40)
    
    train_losses, best_recall = train_model(
        model=model,
        train_loader=train_loader,
        val_evaluator=val_evaluator,
        optimizer=optimizer,
        criterion=criterion,
        epochs=50
    )
    
    # 7. 测试最佳模型
    print("\n[5/6] Testing Best Model")
    print("-" * 40)
    
    # 加载最佳模型
    model.load_state_dict(torch.load('best_mf_bpr_model.pth', map_location=device))
    
    # 在测试集上评估
    print("\nTest Set Evaluation:")
    test_recall, test_ndcg, test_hit_rate = test_evaluator.evaluate(model)
    
    # 8. 保存结果
    results = {
        "data_statistics": {
            "n_users": dataset.n_users,
            "n_items": dataset.n_items,
            "train_interactions": len(dataset.train_df),
            "valid_interactions": len(dataset.valid_df),
            "test_interactions": len(dataset.test_df)
        },
        "model_config": {
            "embedding_dim": 128,
            "num_negatives": 4,
            "batch_size": 512,
            "learning_rate": 0.001
        },
        "training": {
            "epochs_trained": len(train_losses),
            "best_val_recall": best_recall,
            "final_train_loss": train_losses[-1] if train_losses else 0
        },
        "test_evaluation": {
            "recall@20": test_recall,
            "ndcg@20": test_ndcg,
            "hitrate@20": test_hit_rate
        }
    }
    
    # 保存结果到JSON文件
    with open('mf_bpr_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to mf_bpr_results.json")
    
    # 9. 打印最终结果摘要
    print("\n" + "="*60)
    print("FINAL RESULTS SUMMARY")
    print("="*60)
    print(f"Best Validation Recall@20: {best_recall:.4f}")
    print(f"Test Recall@20: {test_recall:.4f}")
    print(f"Test NDCG@20: {test_ndcg:.4f}")
    print(f"Test HitRate@20: {test_hit_rate:.4f}")
    
    return results

# ========== 运行主函数 ==========
if __name__ == "__main__":
    try:
        start_time = time.time()
        results = main()
        total_time = time.time() - start_time
        print(f"\nTotal execution time: {total_time:.1f} seconds")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()