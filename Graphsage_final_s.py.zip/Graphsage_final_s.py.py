import os, zipfile, glob, random, math
import numpy as np, pandas as pd
from collections import defaultdict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingLR
from tqdm import tqdm

# ================= Config =================
BASE_DIR = "/root/ly_env"
DATA_ZIP = f"{BASE_DIR}/data_300W_user_30000.zip"
DATA_DIR = f"{BASE_DIR}/data_300W_user_30000"
MODEL_PATH = f"{BASE_DIR}/best_GraphSAGE_mode4.pth"

seed = 42
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
if device.type == "cuda":
    torch.cuda.manual_seed_all(seed)

# ====== Optimized for BETTER Recall / NDCG (NO model change) ======
embedding_dim = 128
neighbor_sample_size = 80          # ↑ 更丰富邻居
lr = 0.001
weight_decay = 1e-6
batch_size = 256
eval_batch_size = 512
epochs = 20                        # ↑ 更充分收敛
K = 20
grad_clip = 3.0                   # ↓ 稳定梯度

n_neg = 120                       # ↑ 更强负样本
temp = 0.7                        # ↑ 排序稳定

use_dynamic_neighbor_sampling = True
dynamic_sample_freq = 1           # 每个 epoch 重采

behavior_weights = {"pv": 0.1, "fav": 0.3, "cart": 0.6, "buy": 1.0}

neg_mix_uniform = 0.10             # ↓ 更多热门 hard negative
# ============================================================

# ================= Data =================
def unzip_if_needed():
    os.makedirs(DATA_DIR, exist_ok=True)
    if any(os.scandir(DATA_DIR)):
        return
    with zipfile.ZipFile(DATA_ZIP, "r") as zf:
        zf.extractall(DATA_DIR)

def detect_split_files():
    csvs = glob.glob(f"{DATA_DIR}/**/*.csv", recursive=True)
    train = val = test = None
    for p in csvs:
        n = os.path.basename(p).lower()
        if "train" in n and not train:
            train = p
        elif ("val" in n or "valid" in n) and not val:
            val = p
        elif "test" in n and not test:
            test = p
    return train, val, test

def load_data():
    unzip_if_needed()
    t, v, s = detect_split_files()
    train, val, test = map(pd.read_csv, [t, v, s])

    all_df = pd.concat([train, val, test], ignore_index=True)
    users = all_df["user_id"].unique()
    items = all_df["item_id"].unique()

    user_map = {u: i for i, u in enumerate(users)}
    item_map = {it: len(users) + j for j, it in enumerate(items)}

    for df in (train, val, test):
        df["user_idx"] = df["user_id"].map(user_map)
        df["item_idx_global"] = df["item_id"].map(item_map)

    print(f"用户数: {len(users):,}, 物品数: {len(items):,}, 总节点: {len(users)+len(items):,}")
    return train, val, test, len(users), len(items)

# ================= Graph =================
def build_adj_list(df):
    adj, adj_w = defaultdict(list), defaultdict(list)
    for r in df.itertuples(index=False):
        w = behavior_weights.get(getattr(r, "behavior_type", None), 0.1)
        adj[r.user_idx].append(r.item_idx_global)
        adj[r.item_idx_global].append(r.user_idx)
        adj_w[r.user_idx].append(w)
        adj_w[r.item_idx_global].append(w)
    return adj, adj_w

def prepare_neighbor_tensor(adj, adj_w, ns, total):
    neigh = np.zeros((total, ns), dtype=np.int64)
    for i in range(total):
        nodes = adj.get(i)
        if nodes is None:
            neigh[i] = i
        else:
            w = adj_w[i]
            p = None if sum(w) == 0 else np.array(w) / sum(w)
            neigh[i] = np.random.choice(nodes, ns, True, p=p)
    return torch.from_numpy(neigh).long().to(device)

def build_item_popularity(df, num_users, num_items):
    cnt = np.zeros(num_items)
    for r in df.itertuples(index=False):
        idx = r.item_idx_global - num_users
        if 0 <= idx < num_items:
            cnt[idx] += 1
    return (cnt + 1) / (cnt.sum() + num_items)

# ================= Model (UNCHANGED) =================
class GraphSAGE(nn.Module):
    def __init__(self, total_nodes, dim, ns, dropout=0.2):
        super().__init__()
        self.embedding = nn.Embedding(total_nodes, dim)
        nn.init.xavier_uniform_(self.embedding.weight)
        self.lin1 = nn.Linear(dim * 3, dim)
        self.lin2 = nn.Linear(dim * 2, dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)

    def agg(self, nodes, neigh):
        h = self.embedding(nodes)
        ne = self.embedding(neigh)
        m, mx = ne.mean(1), ne.max(1).values
        x = torch.cat([h, m, mx], 1)
        return self.dropout(self.norm1(self.relu(self.lin1(x))))

    def forward(self, nodes, neigh):
        h1 = self.agg(nodes, neigh)
        hn = self.embedding(neigh).mean(1)
        x = torch.cat([h1, hn], 1)
        return F.normalize(self.dropout(self.norm2(self.relu(self.lin2(x)))), 2, -1)

# ================= Train =================
def train_one_epoch(model, opt, user_list, user_items, exclude_sets,
                    neigh, num_items, item_pop_p):

    model.train()
    random.shuffle(user_list)
    total = (len(user_list) + batch_size - 1) // batch_size
    loss_total = 0.0

    for bi in range(total):
        bu = user_list[bi*batch_size:(bi+1)*batch_size]
        if not bu:
            continue

        bu_t = torch.tensor(bu, device=device)
        pos_t = torch.tensor([random.choice(user_items[u]) for u in bu], device=device)

        neg_pop = np.random.choice(num_items, size=(len(bu), n_neg), p=item_pop_p)
        neg_uni = np.random.randint(0, num_items, size=(len(bu), n_neg))
        mask = (np.random.rand(len(bu), n_neg) < neg_mix_uniform)
        neg_local = np.where(mask, neg_uni, neg_pop)

        for i, u in enumerate(bu):
            bad = exclude_sets[u]
            for j in range(n_neg):
                if neg_local[i, j] in bad:
                    for _ in range(50):
                        x = random.randrange(num_items) if random.random() < neg_mix_uniform \
                            else int(np.random.choice(num_items, p=item_pop_p))
                        if x not in bad:
                            neg_local[i, j] = x
                            break

        neg_t = torch.from_numpy(neg_local).long().to(device) + model.num_users

        nodes = torch.cat([bu_t, pos_t, neg_t.view(-1)])
        uniq, inv = torch.unique(nodes, return_inverse=True)
        emb = model(uniq, neigh[uniq])

        B = len(bu)
        u = emb[inv[:B]]
        p = emb[inv[B:2*B]]
        n = emb[inv[2*B:]].view(B, n_neg, embedding_dim)

        pos_score = (u * p).sum(1, keepdim=True) / temp
        neg_score = (u.unsqueeze(1) * n).sum(2) / temp
        loss = -F.logsigmoid(pos_score - neg_score).mean()

        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        opt.step()

        loss_total += loss.item()

    return loss_total / max(1, total)

# ================= Eval (UNCHANGED) =================
def recall_at_k(top_items, gt, k):
    return 1.0 if gt in top_items[:k] else 0.0

def hit_rate_at_k(top_items, gt, k):
    return 1.0 if gt in top_items[:k] else 0.0

def ndcg_at_k(top_items, gt, k):
    if gt not in top_items[:k]:
        return 0.0
    return 1.0 / math.log2(top_items.index(gt) + 2)

def compute_item_emb_with_encoder(model, neigh_tensor, num_users, num_items, chunk=4096):
    model.eval()
    outs = []
    with torch.no_grad():
        for start in range(0, num_items, chunk):
            end = min(start + chunk, num_items)
            item_global = torch.arange(num_users + start, num_users + end, device=device)
            outs.append(model(item_global, neigh_tensor[item_global]).cpu())
    return torch.cat(outs, 0).to(device)

def evaluate_like_lightgcn_style(model, eval_df, neigh_tensor,
                                 num_users, num_items, topk=20, seen=None):
    model.eval()
    users = eval_df["user_idx"].values
    gt_items = (eval_df["item_idx_global"] - num_users).values

    with torch.no_grad():
        item_emb = compute_item_emb_with_encoder(model, neigh_tensor, num_users, num_items)

    recalls, ndcgs, hits = [], [], []
    eff_topk = min(topk, num_items)

    with torch.no_grad():
        for start in range(0, len(users), eval_batch_size):
            end = min(start + eval_batch_size, len(users))
            bu = users[start:end]
            u_emb = model(torch.LongTensor(bu).to(device), neigh_tensor[bu])
            scores = (u_emb @ item_emb.t()).cpu().numpy()

            for i, u in enumerate(bu):
                gt = int(gt_items[start + i])
                if seen and u in seen:
                    hide = [x for x in seen[u] if x != gt]
                    scores[i, hide] = -1e9
                top = np.argpartition(-scores[i], eff_topk-1)[:eff_topk]
                top = top[np.argsort(scores[i][top])[::-1]].tolist()
                recalls.append(recall_at_k(top, gt, topk))
                ndcgs.append(ndcg_at_k(top, gt, topk))
                hits.append(hit_rate_at_k(top, gt, topk))

    return float(np.mean(recalls)), float(np.mean(ndcgs)), float(np.mean(hits))

# ================= Main =================
if __name__ == "__main__":
    train_df, val_df, test_df, num_users, num_items = load_data()
    total_nodes = num_users + num_items

    adj, adj_w = build_adj_list(train_df)
    neigh = prepare_neighbor_tensor(adj, adj_w, neighbor_sample_size, total_nodes)
    item_pop_p = build_item_popularity(train_df, num_users, num_items)

    user_items = defaultdict(list)
    for r in train_df.itertuples(index=False):
        user_items[r.user_idx].append(r.item_idx_global)

    exclude_sets = {u: set(i - num_users for i in items) for u, items in user_items.items()}

    model = GraphSAGE(total_nodes, embedding_dim, neighbor_sample_size).to(device)
    model.num_users = num_users
    opt = Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = CosineAnnealingLR(opt, T_max=epochs, eta_min=lr * 0.2)

    best_ndcg, best_epoch = 0.0, 0
    print("\n开始训练 GraphSAGE...\n")

    for epoch in tqdm(range(1, epochs + 1), desc="Epoch", dynamic_ncols=True):
        neigh = prepare_neighbor_tensor(adj, adj_w, neighbor_sample_size, total_nodes)

        loss = train_one_epoch(model, opt, list(user_items.keys()),
                               user_items, exclude_sets,
                               neigh, num_items, item_pop_p)
        scheduler.step()

        recall, ndcg, hitrate = evaluate_like_lightgcn_style(
            model, val_df, neigh, num_users, num_items, topk=K, seen=exclude_sets
        )

        tqdm.write(
            f"Epoch {epoch} | Loss={loss:.4f} | Recall@{K}={recall:.4f} | "
            f"NDCG@{K}={ndcg:.4f} | HitRate@{K}={hitrate:.4f}"
        )

        if ndcg > best_ndcg:
            best_ndcg, best_epoch = ndcg, epoch
            torch.save(
                {"state_dict": model.state_dict(),
                 "num_users": num_users,
                 "num_items": num_items,
                 "epoch": epoch},
                MODEL_PATH
            )
            tqdm.write(f"[Saved Best] {MODEL_PATH}  NDCG={best_ndcg:.4f}")

    recall, ndcg, hitrate = evaluate_like_lightgcn_style(
        model, test_df, neigh, num_users, num_items, topk=K, seen=exclude_sets
    )

    print(f"\n训练结束。最佳验证 NDCG@{K}={best_ndcg:.4f}（Epoch {best_epoch}），已保存到：{MODEL_PATH}")
    print(f"Recall@{K}={recall:.4f} | NDCG@{K}={ndcg:.4f} | HitRate@{K}={hitrate:.4f}")