import argparse
import sys
import random

def run(
    data_path: str,
    output_path: str,
    light_samples: int,
    seed: int,
    has_header: bool,
    min_interactions: int,
):
    try:
        import polars as pl
    except Exception:
        print("polars not available", file=sys.stderr)
        sys.exit(1)
    try:
        from tqdm import tqdm
        bar = tqdm(total=4)
        bar.set_description("sampling")
    except Exception:
        bar = None
    if bar:
        bar.update(1)
    df = pl.read_csv(data_path, has_header=has_header)
    if bar:
        bar.update(1)
    # 标准化列名以兼容下游脚本
    names = df.columns
    if len(names) >= 5:
        df = df.select(names[:5])
        df = df.rename(
            {
                names[0]: "user_id",
                names[1]: "item_id",
                names[2]: "category_id",
                names[3]: "behavior_type",
                names[4]: "timestamp",
            }
        )
    if min_interactions and min_interactions > 1:
        keep_users = (
            df.group_by("user_id").len().filter(pl.col("len") >= min_interactions).select("user_id")
        )
        df = df.join(keep_users, on="user_id", how="inner")
        df = df.with_row_index("__ri__")
        users = df.select("user_id").unique()["user_id"].to_list()
        if not users:
            out = df.select(["user_id", "item_id", "category_id", "behavior_type", "timestamp"]) 
        else:
            num_users = light_samples // min_interactions if light_samples >= min_interactions else 1
            if num_users < 1:
                num_users = 1
            if num_users > len(users):
                num_users = len(users)
            rng = random.Random(seed)
            sel_users = rng.sample(users, num_users)
            parts = []
            extras = []
            for i, u in enumerate(sel_users):
                ud = df.filter(pl.col("user_id") == u)
                base = ud.sample(n=min_interactions, shuffle=True, seed=seed + i)
                parts.append(base)
                rem = ud.filter(~pl.col("__ri__").is_in(base["__ri__"].to_list()))
                if rem.height > 0:
                    extras.append(rem)
            out = pl.concat(parts) if parts else pl.DataFrame([])
            remain = light_samples - out.height
            if remain > 0 and extras:
                extra_pool = pl.concat(extras)
                take = remain if remain < extra_pool.height else extra_pool.height
                add = extra_pool.sample(n=take, shuffle=True, seed=seed + 999)
                out = pl.concat([out, add])
            out = out.select(["user_id", "item_id", "category_id", "behavior_type", "timestamp"]) 
    else:
        n = df.height
        k = light_samples if light_samples < n else n
        out = df.sample(n=k, shuffle=True, seed=seed)
    out = out.select(["user_id", "item_id", "category_id", "behavior_type", "timestamp"])
    # 强制时间列为整数字符串，避免后续 lazy cast 报错
    out = out.with_columns(
        [
            pl.col("timestamp").cast(pl.Int64).cast(pl.Utf8),
            pl.col("user_id").cast(pl.Utf8),
            pl.col("item_id").cast(pl.Utf8),
            pl.col("category_id").cast(pl.Utf8),
            pl.col("behavior_type").cast(pl.Utf8),
        ]
    )
    out.write_csv(output_path, include_header=has_header)
    if bar:
        bar.update(2)
        bar.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_path", type=str, required=True)
    parser.add_argument("--output_path", type=str, required=True)
    parser.add_argument("--light_samples", type=int, required=True)
    parser.add_argument("--seed", type=int, default=2025)
    parser.add_argument("--has_header", type=str, default="True")
    parser.add_argument("--min_interactions", type=int, default=1)
    args = parser.parse_args()
    run(
        data_path=args.data_path,
        output_path=args.output_path,
        light_samples=args.light_samples,
        seed=args.seed,
        has_header=(args.has_header.lower() == "true"),
        min_interactions=args.min_interactions,
    )

if __name__ == "__main__":
    main()
